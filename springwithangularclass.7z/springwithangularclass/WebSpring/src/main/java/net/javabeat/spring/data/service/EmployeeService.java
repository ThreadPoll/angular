package net.javabeat.spring.data.service;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;

import net.javabeat.spring.data.domain.Employee;

public interface EmployeeService {

	public List<Employee> findAll();
	public void addEmployee(Employee employee);
	
	@Cacheable("employees")
	public void delete(long empId);
}
