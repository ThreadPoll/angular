package net.javabeat.spring.data.service;

import java.util.List;

import net.javabeat.spring.data.domain.Employee;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	
}
