package net.javabeat.spring.data.web;

import java.util.List;

import net.javabeat.spring.data.domain.Employee;
import net.javabeat.spring.data.service.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("/")
	public List<Employee> getEmployees(){
		return employeeService.findAll();
	}
	
	@RequestMapping(value = "/add/{id}/{name}/{address}")
	public Employee addEmployees(@PathVariable int id , @PathVariable String name , @PathVariable String address){
		Employee employee = new Employee(id, name, address);
		employeeService.addEmployee(employee);
		return employee;
	}
	
	@RequestMapping(value = "/delete/{id}")
	public void addEmployees(@PathVariable int id){
		employeeService.delete(id);
	}
}
