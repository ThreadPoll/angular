package com.globozor.domain.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name="paymentMethod")
@Entity(name="paymentMethod")
public class PaymentMethod {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="paymentMethodIdGenerator")
	@SequenceGenerator(name="paymentMethodIdGenerator", sequenceName="seq_payment_method")
	private long paymentMethodId;
	
	@Column
	private String paymentName;
	
	@Column
	private String description;
	
	public PaymentMethod() {
		// TODO Auto-generated constructor stub
	}

	public PaymentMethod(long paymentMethodId, String paymentName,
			String description) {
		super();
		this.paymentMethodId = paymentMethodId;
		this.paymentName = paymentName;
		this.description = description;
	}

	public long getPaymentMethodId() {
		return paymentMethodId;
	}

	public void setPaymentMethodId(long paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}

	public String getPaymentName() {
		return paymentName;
	}

	public void setPaymentName(String paymentName) {
		this.paymentName = paymentName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "PaymentMethod [paymentMethodId=" + paymentMethodId
				+ ", paymentName=" + paymentName + ", description="
				+ description + "]";
	}
	
}
