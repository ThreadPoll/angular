package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{
	public Product findByProductName(String productName);
}
