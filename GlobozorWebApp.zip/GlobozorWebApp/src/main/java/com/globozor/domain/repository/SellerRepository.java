package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.Seller;

public interface SellerRepository extends JpaRepository<Seller, Long>{
	public Seller findBySellerId(long sellerId);
}
