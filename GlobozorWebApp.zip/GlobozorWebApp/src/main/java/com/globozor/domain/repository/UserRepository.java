package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.User;

public interface UserRepository extends JpaRepository<User, Long>{
	public User findByUserId(long userId);
}
