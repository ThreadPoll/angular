package com.globozor.domain.dtos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="seller")
@Entity(name="seller")
public class Seller {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="sellerIdGenerator")
	@SequenceGenerator(name="sellerIdGenerator", sequenceName="seq_Seller")
	@Column
	private long sellerId;
	
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="seller_paymentmethod", joinColumns = @JoinColumn(name="sellerId",referencedColumnName="sellerId"), inverseJoinColumns=@JoinColumn(name="paymentMethodId",referencedColumnName="paymentMethodId"))
	private Set<PaymentMethod> paymentMethod;
	
	@Column
	private String firstName;
	
	@Column
	private String lastName;
	
	@Column
	private String companyName;
	
	@Column
	private String addressLine1;
	
	@Column
	private String addressLine2;
	
	@Column
	private String sellerCity;
	
	@Column
	private long sellerPincode;
	
	@Column
	private String sellerState;
	
	@Column
	private String sellerCountry;
	
	@Column
	private String sellerPannumber;
	
	@Column
	private String sellerIeccodenumber;
	
	@Column
	private String sellerSalestaxnumber;

	@Column
	private String isVerifiedSeller;
	
	@OneToOne
	@JoinColumn(name="sellerDescriptionId")
	@JsonIgnore
	private SellerDescription sellerDescription;
	
	@OneToMany(mappedBy="seller",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private Set<SellerProduct> sellerProduct;	
	
	public Seller() {

	}

	public Seller(long sellerId, User user, Set<PaymentMethod> paymentMethod,
			String firstName, String lastName, String companyName,
			String addressLine1, String addressLine2, String sellerCity,
			long sellerPincode, String sellerState, String sellerCountry,
			String sellerPannumber, String sellerIeccodenumber,
			String sellerSalestaxnumber, String isVerifiedSeller,
			SellerDescription sellerDescription) {
		super();
		this.sellerId = sellerId;
		this.user = user;
		this.paymentMethod = paymentMethod;
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.sellerCity = sellerCity;
		this.sellerPincode = sellerPincode;
		this.sellerState = sellerState;
		this.sellerCountry = sellerCountry;
		this.sellerPannumber = sellerPannumber;
		this.sellerIeccodenumber = sellerIeccodenumber;
		this.sellerSalestaxnumber = sellerSalestaxnumber;
		this.isVerifiedSeller = isVerifiedSeller;
		this.sellerDescription = sellerDescription;
		this.sellerProduct = sellerProduct;
	}

	public long getSellerId() {
		return sellerId;
	}

	public void setSellerId(long sellerId) {
		this.sellerId = sellerId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<PaymentMethod> getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(Set<PaymentMethod> paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getSellerCity() {
		return sellerCity;
	}

	public void setSellerCity(String sellerCity) {
		this.sellerCity = sellerCity;
	}

	public long getSellerPincode() {
		return sellerPincode;
	}

	public void setSellerPincode(long sellerPincode) {
		this.sellerPincode = sellerPincode;
	}

	public String getSellerState() {
		return sellerState;
	}

	public void setSellerState(String sellerState) {
		this.sellerState = sellerState;
	}

	public String getSellerCountry() {
		return sellerCountry;
	}

	public void setSellerCountry(String sellerCountry) {
		this.sellerCountry = sellerCountry;
	}

	public String getSellerPannumber() {
		return sellerPannumber;
	}

	public void setSellerPannumber(String sellerPannumber) {
		this.sellerPannumber = sellerPannumber;
	}

	public String getSellerIeccodenumber() {
		return sellerIeccodenumber;
	}

	public void setSellerIeccodenumber(String sellerIeccodenumber) {
		this.sellerIeccodenumber = sellerIeccodenumber;
	}

	public String getSellerSalestaxnumber() {
		return sellerSalestaxnumber;
	}

	public void setSellerSalestaxnumber(String sellerSalestaxnumber) {
		this.sellerSalestaxnumber = sellerSalestaxnumber;
	}

	public String getIsVerifiedSeller() {
		return isVerifiedSeller;
	}

	public void setIsVerifiedSeller(String isVerifiedSeller) {
		this.isVerifiedSeller = isVerifiedSeller;
	}

	public SellerDescription getSellerDescription() {
		return sellerDescription;
	}

	public void setSellerDescription(SellerDescription sellerDescription) {
		this.sellerDescription = sellerDescription;
	}

	public Set<SellerProduct> getSellerProduct() {
		return sellerProduct;
	}

	public void setSellerProduct(Set<SellerProduct> sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	@Override
	public String toString() {
		return "Seller [sellerId=" + sellerId + ", user=" + user
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", companyName=" + companyName + ", addressLine1="
				+ addressLine1 + ", addressLine2=" + addressLine2
				+ ", sellerCity=" + sellerCity + ", sellerPincode="
				+ sellerPincode + ", sellerState=" + sellerState
				+ ", sellerCountry=" + sellerCountry + ", sellerPannumber="
				+ sellerPannumber + ", sellerIeccodenumber="
				+ sellerIeccodenumber + ", sellerSalestaxnumber="
				+ sellerSalestaxnumber + ", isVerifiedSeller="
				+ isVerifiedSeller + ", sellerDescription=" + sellerDescription;
	}

}
