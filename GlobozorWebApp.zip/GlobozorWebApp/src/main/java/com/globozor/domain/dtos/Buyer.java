package com.globozor.domain.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name="buyer")
@Entity(name="buyer")
public class Buyer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="buyerIdGenerator")
	@SequenceGenerator(name="buyerIdGenerator", sequenceName="seq_Buyer")
	@Column
	private long buyerId;
	
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	
	@Column
	private String firstName;
	
	@Column
	private String lastName;
	
	@Column
	private String companyName;
	
	@Column
	private String addressLine1;
	
	@Column
	private String addressLine2;
	
	@Column
	private String buyerCity;
	
	@Column(name="buyerPincode")
	private long buyerPinCode;
	
	@Column
	private String buyerState;
	
	@Column
	private String buyerCountry;

	@Column
	private String buyerWebsiteUrl;
	
	@Column(name="buyerPannumber")
	private String buyerPanNumber;
	
	@Column(name="buyerIeccodenumber")
	private String buyerIecCodeNumber;
	
	@Column(name="buyerSalestaxnumber")
	private String buyerSalesTaxNumber;

	@Column
	private String isVerifiedBuyer;
	
	public Buyer() {

	}

	public Buyer(long buyerId, User user, String firstName, String lastName,
			String companyName, String addressLine1, String addressLine2,
			String buyerCity, long buyerPinCode, String buyerState,
			String buyerCountry, String buyerWebsiteUrl, String buyerPanNumber,
			String buyerIecCodeNumber, String buyerSalesTaxNumber,
			String isVerifiedBuyer) {
		super();
		this.buyerId = buyerId;
		this.user = user;
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.buyerCity = buyerCity;
		this.buyerPinCode = buyerPinCode;
		this.buyerState = buyerState;
		this.buyerCountry = buyerCountry;
		this.buyerWebsiteUrl = buyerWebsiteUrl;
		this.buyerPanNumber = buyerPanNumber;
		this.buyerIecCodeNumber = buyerIecCodeNumber;
		this.buyerSalesTaxNumber = buyerSalesTaxNumber;
		this.isVerifiedBuyer = isVerifiedBuyer;
	}

	public long getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(long buyerId) {
		this.buyerId = buyerId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getBuyerCity() {
		return buyerCity;
	}

	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	public long getBuyerPinCode() {
		return buyerPinCode;
	}

	public void setBuyerPinCode(long buyerPinCode) {
		this.buyerPinCode = buyerPinCode;
	}

	public String getBuyerState() {
		return buyerState;
	}

	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	public String getBuyerCountry() {
		return buyerCountry;
	}

	public void setBuyerCountry(String buyerCountry) {
		this.buyerCountry = buyerCountry;
	}

	public String getBuyerWebsiteUrl() {
		return buyerWebsiteUrl;
	}

	public void setBuyerWebsiteUrl(String buyerWebsiteUrl) {
		this.buyerWebsiteUrl = buyerWebsiteUrl;
	}

	public String getBuyerPanNumber() {
		return buyerPanNumber;
	}

	public void setBuyerPanNumber(String buyerPanNumber) {
		this.buyerPanNumber = buyerPanNumber;
	}

	public String getBuyerIecCodeNumber() {
		return buyerIecCodeNumber;
	}

	public void setBuyerIecCodeNumber(String buyerIecCodeNumber) {
		this.buyerIecCodeNumber = buyerIecCodeNumber;
	}

	public String getBuyerSalesTaxNumber() {
		return buyerSalesTaxNumber;
	}

	public void setBuyerSalesTaxNumber(String buyerSalesTaxNumber) {
		this.buyerSalesTaxNumber = buyerSalesTaxNumber;
	}

	public String getIsVerifiedBuyer() {
		return isVerifiedBuyer;
	}

	public void setIsVerifiedBuyer(String isVerifiedBuyer) {
		this.isVerifiedBuyer = isVerifiedBuyer;
	}

	@Override
	public String toString() {
		return "Buyer [buyerId=" + buyerId + ", user=" + user + ", firstName="
				+ firstName + ", lastName=" + lastName + ", companyName="
				+ companyName + ", addressLine1=" + addressLine1
				+ ", addressLine2=" + addressLine2 + ", buyerCity=" + buyerCity
				+ ", buyerPinCode=" + buyerPinCode + ", buyerState="
				+ buyerState + ", buyerCountry=" + buyerCountry
				+ ", buyerWebsiteUrl=" + buyerWebsiteUrl + ", buyerPanNumber="
				+ buyerPanNumber + ", buyerIecCodeNumber=" + buyerIecCodeNumber
				+ ", buyerSalesTaxNumber=" + buyerSalesTaxNumber
				+ ", isVerifiedBuyer=" + isVerifiedBuyer + "]";
	}
	
}
