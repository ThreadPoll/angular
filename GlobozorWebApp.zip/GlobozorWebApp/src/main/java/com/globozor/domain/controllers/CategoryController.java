package com.globozor.domain.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.Category;
import com.globozor.domain.services.CategoryService;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/category")
public class CategoryController {

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/saveCategory",method=RequestMethod.POST)
	public Category saveCategory(@RequestBody Category category){
			category = categoryService.saveCategory(category);
			return category;
	}
}
