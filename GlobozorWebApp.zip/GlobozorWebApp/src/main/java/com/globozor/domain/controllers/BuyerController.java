package com.globozor.domain.controllers;

import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.services.BuyerService;
import com.globozor.domain.services.UserService;
import com.globozor.domain.dtos.Buyer;
import com.globozor.domain.dtos.Seller;
import com.globozor.domain.dtos.User;

@RestController
@RequestMapping("/buyer")
public class BuyerController {

	@Autowired
	BuyerService buyerService;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/saveBuyer",method=RequestMethod.POST)
	public Buyer saveBuyer(@RequestBody Buyer buyer){
		User user = userService.isUser(buyer.getUser());
		if(!(user==null)){
			return buyerService.saveBuyer(buyer);
		}
		return null;
	}
	
	@RequestMapping(value="/deleteBuyer",method=RequestMethod.DELETE)
	public Buyer deleteBuyer(@RequestBody Buyer buyer){
		User user = userService.isUser(buyer.getUser());
		if(!(user==null)){
			buyer.setUser(user);
			return buyerService.deleteBuyer(buyer);
		}
		return null;
	}
	
	@RequestMapping(value="/updateBuyer",method=RequestMethod.PUT)
	public Buyer updateBuyer(@RequestBody Buyer buyer){
		User user = userService.isUser(buyer.getUser());
		if(!(user==null)){
			buyer.setUser(user);
			return buyerService.updateBuyer(buyer);
		}
		return null;
	}
	
	@RequestMapping(value="/searchProduct",method=RequestMethod.GET)
	public Set<Seller> searchProduct(@RequestParam String searchProduct){
		Object object = buyerService.searchProduct(searchProduct);
		Set<Seller> sellerList = buyerService.searchSellers(object);
		System.out.println("Object is "+object);
		System.out.println("Object2 is "+sellerList);
		return sellerList;
	}
}
