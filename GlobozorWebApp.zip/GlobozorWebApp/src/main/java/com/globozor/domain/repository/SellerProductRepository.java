package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.dtos.SellerProduct;

public interface SellerProductRepository extends JpaRepository<SellerProduct, Long>{
	
	public SellerProduct findBySellerProductId(long sellerProductId);
	@Query("select s from sellerProduct s where s.subProduct.subProductId=?1")
	public List<SellerProduct> findBySubProductId(long subProductId);
}
