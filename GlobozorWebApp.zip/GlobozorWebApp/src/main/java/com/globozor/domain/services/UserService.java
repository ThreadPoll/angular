package com.globozor.domain.services;

import com.globozor.domain.dtos.User;

public interface UserService {
	public User saveUser(User user);
	public User isUser(User user);
	public User deleteUser(User user);
	public User updateUser(User user);
}
