package com.globozor.domain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.dtos.User;
import com.globozor.domain.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;

	@Override
	public User saveUser(User user) {
		user=userRepository.save(user);
		return user;
	}
	
	@Override
	public User isUser(User user) {
		User users = userRepository.findByUserId(user.getUserId());
		System.out.println("User is "+users);
		if(!((user.getUserId()==users.getUserId())
				&&(user.getPassword().equals(users.getPassword())))){
			users=null;
		}
		return users;
	}

	@Override
	public User deleteUser(User user) {
		userRepository.delete(user.getUserId());
		return null;
	}

	@Override
	public User updateUser(User user) {
		user = userRepository.save(user);
		return user;
	}

}
