package com.globozor.domain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.dtos.Category;
import com.globozor.domain.repository.CategoryRepository;


@Service
@Transactional
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	CategoryRepository categoryRepository; 
	
	@Override
	public Category saveCategory(Category category) {
		return categoryRepository.save(category);
	}

	@Override
	public Category deleteCategory(Category category) {
		categoryRepository.delete(category);
		return null;
	}

	@Override
	public Category updateCategory(Category category) {
		return categoryRepository.save(category);
	}

}
