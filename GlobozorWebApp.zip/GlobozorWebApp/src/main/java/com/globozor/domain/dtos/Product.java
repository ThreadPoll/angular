package com.globozor.domain.dtos;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Table(name="product")
@Entity(name="product")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="productIdGenerator")
	@SequenceGenerator(name="productIdGenerator", sequenceName="seq_product")
	private long productId;
	
	@Column
	private String productName;
	
	@Column
	private String productDescription;
	
	@ManyToMany(cascade=CascadeType.MERGE)
	@JoinTable(name = "productSubproduct", joinColumns = @JoinColumn(name = "productId", referencedColumnName = "productId"), inverseJoinColumns = @JoinColumn(name = "subproductId", referencedColumnName = "subproductId"))
	private List<SubProduct> subProduct;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(long productId, String productName,
			String productDescription, List<SubProduct> subProduct) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.subProduct = subProduct;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public List<SubProduct> getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(List<SubProduct> subProduct) {
		this.subProduct = subProduct;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productDescription=" + productDescription
				+ ", subProduct=" + subProduct + "]";
	}
	
}
