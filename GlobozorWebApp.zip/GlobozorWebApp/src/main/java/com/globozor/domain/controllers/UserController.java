package com.globozor.domain.controllers;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.globozor.domain.dtos.User;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	UserService userService;
	
	ObjectMapper objectMapper = new ObjectMapper();
	JSONParser parser = new JSONParser();
	User user = null;
	
	@RequestMapping(value="/saveUser",method=RequestMethod.POST)
	public JSONObject saveUser(@RequestBody JSONObject jsonObject){
		try {
			user = objectMapper.readValue(jsonObject.toString(), User.class);
			user = userService.saveUser(user);
			String jsonString = objectMapper.writeValueAsString(user);
			jsonObject = (JSONObject) parser.parse(jsonString);

		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value="/isUser", method = RequestMethod.POST)
	public JSONObject isUser(@RequestBody JSONObject jsonObject){
		try {
			user = objectMapper.readValue(jsonObject.toString(), User.class);
			user = userService.isUser(user);
			String jsonString = objectMapper.writeValueAsString(user);
			jsonObject = (JSONObject) parser.parse(jsonString);
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@SuppressWarnings({ "unchecked", "null" })
	@RequestMapping(value="/deleteUser", method = RequestMethod.DELETE)
	public JSONObject deleteUser(@RequestBody JSONObject jsonObject){
		
		try {
			user = objectMapper.readValue(jsonObject.toString(), User.class);
			user = userService.isUser(user);
			jsonObject= null;
			if(!(user==null)){
				userService.deleteUser(user);
				jsonObject.put("Status", "User Deleted");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value="/updateUser", method = RequestMethod.PUT)
	public JSONObject updateUser(@RequestBody JSONObject jsonObject){
		try {
			user = objectMapper.readValue(jsonObject.toString(), User.class);
			user = userService.isUser(user);
			if(!(user==null)){
				user = userService.updateUser(user);
				String jsonString = objectMapper.writeValueAsString(user);
				jsonObject = (JSONObject) parser.parse(jsonString);
				return jsonObject;
			}
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
