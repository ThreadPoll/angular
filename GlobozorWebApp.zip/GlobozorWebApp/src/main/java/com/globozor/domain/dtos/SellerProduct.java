package com.globozor.domain.dtos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Table(name="sellerProduct")
@Entity(name="sellerProduct")
public class SellerProduct {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="sellerProductIdGenerator")
	@SequenceGenerator(name="sellerProductIdGenerator", sequenceName="seq_seller_product")
	private long sellerProductId;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="subproductId")
	private SubProduct subProduct;
	
	@ManyToOne
	@JoinColumn(name="sellerid")
	private Seller seller;
	
	@Column
	private String sellerProductName;
	
	@Column
	private String sellerProductDescription;
	
	@Column
	private long minimumQuantity;
	
	@OneToMany(mappedBy="sellerProduct",cascade=CascadeType.ALL)
	private Set<SellerProductImage> sellerProductImage = new HashSet<>();
	
	public SellerProduct() {
		// TODO Auto-generated constructor stub
	}

	public SellerProduct(long sellerProductId, SubProduct subProduct,
			Seller seller, String sellerProductName,
			String sellerProductDescription, long minimumQuantity,
			Set<SellerProductImage> sellerProductImage) {
		super();
		this.sellerProductId = sellerProductId;
		this.subProduct = subProduct;
		this.seller = seller;
		this.sellerProductName = sellerProductName;
		this.sellerProductDescription = sellerProductDescription;
		this.minimumQuantity = minimumQuantity;
		this.sellerProductImage = sellerProductImage;
	}

	public long getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public SubProduct getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(SubProduct subProduct) {
		this.subProduct = subProduct;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public String getSellerProductName() {
		return sellerProductName;
	}

	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}

	public String getSellerProductDescription() {
		return sellerProductDescription;
	}

	public void setSellerProductDescription(String sellerProductDescription) {
		this.sellerProductDescription = sellerProductDescription;
	}

	public long getMinimumQuantity() {
		return minimumQuantity;
	}

	public void setMinimumQuantity(long minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}

	public Set<SellerProductImage> getSellerProductImage() {
		return sellerProductImage;
	}

	public void setSellerProductImage(Set<SellerProductImage> sellerProductImage) {
		this.sellerProductImage = sellerProductImage;
	}

	@Override
	public String toString() {
		return "SellerProduct [sellerProductId=" + sellerProductId
				+ ", seller=" + seller + ", sellerProductName="
				+ sellerProductName + ", sellerProductDescription="
				+ sellerProductDescription + ", minimumQuantity="
				+ minimumQuantity + ", sellerProductImage="
				+ sellerProductImage + "]";
	}
	
}
