package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.Buyer;

public interface BuyerRepository extends JpaRepository<Buyer, Long>{
	public Buyer findByBuyerId(long buyerId);
}
