package com.globozor.domain.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name="sellerDescription")
@Entity(name="sellerDescription")
public class SellerDescription {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="sellerDescriptionIdGenerator")
	@SequenceGenerator(name="sellerDescriptionIdGenerator", sequenceName="seq_seller_description")
	private long sellerDescriptionId;
	
	@Column
	private String descriptionAboutCompany;

	@Column
	private int establishment;
	
	@Column
	private long maximumCapacity;
	
	@Column
	private String sellerImage;
	
	@Column(name="turnover")
	private String turnOver;

	@Column
	private String port;

	@Column(name="sellerWebsiteUrl")
	private String sellerWebsiteUrl;
	
	@Column
	private long numberOfEmployees;
	
	public SellerDescription() {
		// TODO Auto-generated constructor stub
	}

	public SellerDescription(long sellerDescriptionId,
			String descriptionAboutCompany, int establishment,
			long maximumCapacity, String sellerImage, String turnOver,
			String port, String sellerWebsiteUrl, long numberOfEmployees) {
		super();
		this.sellerDescriptionId = sellerDescriptionId;
		this.descriptionAboutCompany = descriptionAboutCompany;
		this.establishment = establishment;
		this.maximumCapacity = maximumCapacity;
		this.sellerImage = sellerImage;
		this.turnOver = turnOver;
		this.port = port;
		this.sellerWebsiteUrl = sellerWebsiteUrl;
		this.numberOfEmployees = numberOfEmployees;
	}

	public long getSellerDescriptionId() {
		return sellerDescriptionId;
	}

	public void setSellerDescriptionId(long sellerDescriptionId) {
		this.sellerDescriptionId = sellerDescriptionId;
	}

	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}

	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}

	public int getEstablishment() {
		return establishment;
	}

	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}

	public long getMaximumCapacity() {
		return maximumCapacity;
	}

	public void setMaximumCapacity(long maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}

	public String getSellerImage() {
		return sellerImage;
	}

	public void setSellerImage(String sellerImage) {
		this.sellerImage = sellerImage;
	}

	public String getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(String turnOver) {
		this.turnOver = turnOver;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getSellerWebsiteUrl() {
		return sellerWebsiteUrl;
	}

	public void setSellerWebsiteUrl(String sellerWebsiteUrl) {
		this.sellerWebsiteUrl = sellerWebsiteUrl;
	}

	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	@Override
	public String toString() {
		return "SellerDescription [sellerDescriptionId=" + sellerDescriptionId
				+ ", descriptionAboutCompany=" + descriptionAboutCompany
				+ ", establishment=" + establishment + ", maximumCapacity="
				+ maximumCapacity + ", sellerImage=" + sellerImage
				+ ", turnOver=" + turnOver + ", port=" + port
				+ ", sellerWebsiteUrl=" + sellerWebsiteUrl
				+ ", numberOfEmployees=" + numberOfEmployees + "]";
	}
}