package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.SubProduct;

public interface SubProductRepository extends JpaRepository<SubProduct, Long>{
	public SubProduct findBySubProductName(String subProductName);
}
