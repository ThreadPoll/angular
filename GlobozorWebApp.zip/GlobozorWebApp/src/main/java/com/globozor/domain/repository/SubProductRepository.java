package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.dtos.SubCategory;
import com.globozor.domain.dtos.SubProduct;

public interface SubProductRepository extends JpaRepository<SubProduct, Long>{
	public SubProduct findBySubProductName(String subProductName);
	/*@Query("select s from subproduct s where s.product.productId=?")
	public List<SubProduct> findByProductId(long productId);*/
}
