package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.dtos.Buyer;
import com.globozor.domain.dtos.Seller;

public interface BuyerService {

	public Buyer saveBuyer(Buyer buyer);
	public Buyer deleteBuyer(Buyer buyer);
	public Buyer updateBuyer(Buyer buyer);
	public Object searchProduct(String searchProduct);
	public List<Seller> searchSellers(Object object);
}
