package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.SubCategory;

public interface SubCategoryRepository extends JpaRepository<SubCategory, Long>{

	public SubCategory findBySubCategoryName(String subCategoryName);
}
