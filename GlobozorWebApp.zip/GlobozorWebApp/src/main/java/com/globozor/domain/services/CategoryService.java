package com.globozor.domain.services;

import com.globozor.domain.dtos.Category;

public interface CategoryService {

	public Category saveCategory(Category category);
	public Category deleteCategory(Category category);
	public Category updateCategory(Category category);
}
