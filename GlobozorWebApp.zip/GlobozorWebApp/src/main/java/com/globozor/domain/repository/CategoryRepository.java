package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.dtos.Category;

public interface CategoryRepository extends JpaRepository<Category, Long>{
	public Category findByCategoryId(long categoryId);
}
