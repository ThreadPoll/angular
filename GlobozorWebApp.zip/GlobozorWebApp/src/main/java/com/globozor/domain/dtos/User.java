package com.globozor.domain.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="Users")
@Table(name="Users")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="userIdGenerator")
	@SequenceGenerator(name="userIdGenerator", sequenceName="seq_users")
	@Column
	private long userId;
	
	@Column
	private String userName;
	
	@Column
	private String emailId;
	
	@Column
	private long mobileNumber;
	
	@Column
	private String password;
	
	@Column
	private boolean isBuyer;

	public User() {

	}
	
	public User(long userId, String userName, String emailId,
			long mobileNumber, String password, boolean isBuyer) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.password = password;
		this.isBuyer = isBuyer;
	}



	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", emailId=" + emailId + ", mobileNumber=" + mobileNumber
				+ ", password=" + password + ", isBuyer=" + isBuyer
				+  "]";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getIsBuyer() {
		return isBuyer;
	}

	public void setBuyer(boolean isBuyer) {
		this.isBuyer = isBuyer;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getUserId() {
		return userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
}
