package com.globozor.domain.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.globozor.domain.dtos.PaymentMethod;
import com.globozor.domain.dtos.Seller;
import com.globozor.domain.dtos.User;
import com.globozor.domain.services.SellerService;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	SellerService sellerService;
	
	@Autowired
	UserService userService;
	
	ObjectMapper objectMapper = new ObjectMapper();
	JSONParser parser = new JSONParser();
	Seller seller = null;
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/saveSeller",method=RequestMethod.POST)
	public JSONObject saveSeller(@RequestBody JSONObject jsonObject){
		
		try {
			seller = objectMapper.readValue(jsonObject.toString(), Seller.class);
			User user = userService.isUser(seller.getUser());
			if(!(user==null)){
				/*List<PaymentMethod> paymentMethodList = new ArrayList<PaymentMethod>();
				paymentMethodList = (List<PaymentMethod>) jsonObject.get("paymentMethod");
				seller.getPaymentMethod().addAll(paymentMethodList);
*/
				System.out.println("seller is "+seller);
				seller.setUser(user);
				seller = sellerService.saveSeller(seller);
				System.out.println("seller is "+seller);
				String jsonString = objectMapper.writeValueAsString(seller);
				jsonObject = (JSONObject) parser.parse(jsonString);
				return jsonObject;
			}
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	/*@SuppressWarnings("unchecked")
	@RequestMapping(value="/saveSeller",method=RequestMethod.POST)
	public Seller saveSeller(@RequestBody Seller seller){
		
			User user = userService.isUser(seller.getUser());
			if(!(user==null)){
				List<PaymentMethod> paymentMethodList = new ArrayList<PaymentMethod>();
				paymentMethodList = (List<PaymentMethod>) seller.getPaymentMethod();
				seller.getPaymentMethod().addAll(paymentMethodList);
				seller = sellerService.saveSeller(seller);
				System.out.println("seller is "+seller);
				return seller;
			}
		
		return null;
	}*/
}
