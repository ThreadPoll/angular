package com.globozor.domain.dtos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Table(name="subcategory")
@Entity(name="subcategory")
public class SubCategory {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="subCategoryIdGenerator")
	@SequenceGenerator(name="subCategoryIdGenerator", sequenceName="seq_subcategory")
	@Column(name="subcategoryId")
	private long subCategoryId;
	
	@Column(name="subcategoryName")
	private String subCategoryName;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "subcategoryProduct", joinColumns = @JoinColumn(name = "subcategoryId", referencedColumnName = "subcategoryId"), inverseJoinColumns = @JoinColumn(name = "productId", referencedColumnName = "productId"))
	private Set<Product> product = new HashSet<>();
	
	public SubCategory() {
		// TODO Auto-generated constructor stub
	}

	public SubCategory(long subCategoryId,
			String subCategoryName, Set<Product> product) {
		super();
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.product = product;
	}

	public long getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(long subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public Set<Product> getProduct() {
		return product;
	}

	public void setProduct(Set<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "SubCategory [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName
				+ ", product=" + product + "]";
	}
	
}
