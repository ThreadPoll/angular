package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.dtos.Buyer;
import com.globozor.domain.dtos.Product;
import com.globozor.domain.dtos.Seller;
import com.globozor.domain.dtos.SellerProduct;
import com.globozor.domain.dtos.SubCategory;
import com.globozor.domain.dtos.SubProduct;
import com.globozor.domain.dtos.User;
import com.globozor.domain.repository.BuyerRepository;
import com.globozor.domain.repository.ProductRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SellerRepository;
import com.globozor.domain.repository.SubCategoryRepository;
import com.globozor.domain.repository.SubProductRepository;
import com.globozor.domain.repository.UserRepository;

@Service
@Transactional
public class BuyerServiceImpl implements BuyerService{

	@Autowired
	BuyerRepository buyerRepository;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	SubCategoryRepository subCategoryRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	SubProductRepository subProductRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	SellerRepository sellerRepository;
	@Override
	public Buyer saveBuyer(Buyer buyer) {
		return buyerRepository.save(buyer);
	}

	@Override
	public Buyer deleteBuyer(Buyer buyer) {
		buyerRepository.delete(buyer);
		return null;
	}

	@Override
	public Buyer updateBuyer(Buyer buyer) {
		return buyerRepository.save(buyer);
	}

	@Override
	public Object searchProduct(String searchProduct) {
		SubCategory subCategory = subCategoryRepository.findBySubCategoryName(searchProduct);
		if(!(subCategory==null)){
			return subCategory;
		}
		Product product = productRepository.findByProductName(searchProduct);
		if(!(product==null)){
			return product;
		}
		
		SubProduct subProduct = subProductRepository.findBySubProductName(searchProduct);
		if(!(subProduct==null)){
			return subProduct;
		}
		return null;
	}

	@Override
	public Set<Seller> searchSellers(Object object) {
		Set<Seller> sellerList = new HashSet<Seller>();
		SubProduct subProduct = null;
		List<SellerProduct> sellerProductList=new ArrayList<SellerProduct>();
		if(object instanceof SubProduct){
			subProduct = (SubProduct) object;
			sellerProductList = 
					sellerProductRepository.findBySubProductId(subProduct.getSubProductId());
			
		}else if(object instanceof Product){
			Product product = (Product) object;
			List<SubProduct> subProductList = product.getSubProduct();
			for (SubProduct subProduct2 : subProductList) {
				List<SellerProduct> sellerProductList1 = 
						sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
				System.out.println("sellerproductlist is "+sellerProductList);
				sellerProductList.addAll(sellerProductList1);
			}
		}else if(object instanceof SubCategory){
			SubCategory subCategory = (SubCategory) object;
			List<Product> productList = subCategory.getProduct();
			for (Product product : productList) {
				List<SubProduct> subProductList = product.getSubProduct();
				for (SubProduct subProduct2 : subProductList) {
					List<SellerProduct> sellerProductList1 = 
							sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
					System.out.println("sellerproductlist is "+sellerProductList);
					sellerProductList.addAll(sellerProductList1);
				}
			}
		}
		for (SellerProduct sellerProduct : sellerProductList) {
			Seller seller = 
					sellerRepository.findBySellerId(sellerProduct.getSeller().getSellerId());
			sellerList.add(seller);
		}
		
		return sellerList;
	}
}
