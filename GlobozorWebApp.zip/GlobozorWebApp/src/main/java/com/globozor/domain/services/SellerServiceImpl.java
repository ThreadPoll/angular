package com.globozor.domain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.dtos.Seller;
import com.globozor.domain.repository.SellerRepository;

@Service
@Transactional
public class SellerServiceImpl implements SellerService {

	@Autowired
	SellerRepository sellerRepository;

	@Override
	public Seller saveSeller(Seller seller) {
		try {
			seller= sellerRepository.save(seller);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return seller;
	}

	@Override
	public Seller deleteSeller(Seller seller) {
		sellerRepository.delete(seller);
		return null;
	}

	@Override
	public Seller updateSeller(Seller seller) {
		return sellerRepository.save(seller);
	}
	
	
}
