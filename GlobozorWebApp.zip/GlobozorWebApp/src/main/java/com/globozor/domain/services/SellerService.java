package com.globozor.domain.services;

import com.globozor.domain.dtos.Seller;

public interface SellerService {
	public Seller saveSeller(Seller seller);
	public Seller deleteSeller(Seller seller);
	public Seller updateSeller(Seller seller);
}
