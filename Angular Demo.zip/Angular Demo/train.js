var app = angular.module("myApp",[])
app.controller("myCtrl", function($scope){
    
    var train=[
        {id:101,name:"Train1",rate:100},
        {id:102,name:"Train2",rate:200},
        {id:103,name:"Train3",rate:300},
        {id:104,name:"Train4",rate:400}
    ];
    
    $scope.train = train;
    
    $scope.perTicketFare=0;
    $scope.passengers=[];
    $scope.totalFare=0;
   
    
    $scope.addPass = function(){
        var pass = {};
        pass.name="";
        pass.age=0;
        $scope.passengers.push(pass);
    }
    
    $scope.addPass();
    
    $scope.delPass = function($index){
        $scope.passengers.splice($index,1);
        alert("passenger deleted"+$index);
    }
    
    $scope.calcFare = function(){
        $scope.totalFare=$scope.totalFare+$scope.perTicketFare*$scope.passengers.length;
        console.log("total"+$scope.totalFare+" per"+$scope.perTicketFare+" num"+$scope.passengers.length);
        return $scope.totalFare;
    }
});

   /* app.filter("myFilter", function(data){
        return function(input){
            if(){
                
            }
        }
    })*/