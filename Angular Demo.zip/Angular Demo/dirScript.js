var app = angular.module("MyApp",[])
app.directive("addItem",function(){
    var obj={
        template:'<div>Adding Item</div>',
        restrict:'AEC'
    }
    return obj;
})