var app = angular.module("myApp",[])
app.controller("myCtrl", function($scope){
    var data=[
        {Name:"Java",State:"false"},
        {Name:"Python",State:"true"},
    ];
    $scope.data = data;
});

app.filter("myFilter",function(){
    return function(input){
       return input=="false"?"No":"Yes";
    };
})