var app = angular.module("MyApp",['ngRoute']);

app.config(function($routeProvider){
    $routeProvider
    .when('/',
         {
            templateUrl:'View1.html',
            controller:'Controller1'
        })
    .when('/View2',
         {
            templateUrl:'View2.html',
            controller:'Controller1'
        })
    .when('/View3',
         {
            templateUrl:'View3.html',
            controller:'Controller2'
        })
    .otherwise('/',
         {
            redirectTo:'/'
        })
});

    app.controller("Controller1", function($scope){
        var currentDateTime = new Date(Date.now());
        $scope.ControllerName="Controller Name : Controller1 - "+
            currentDateTime;
        
    });

app.controller("Controller2", function($scope){
        var currentDateTime = new Date(Date.now());
        $scope.ControllerName="Controller Name : Controller2 - "+
            currentDateTime;
        
    });
