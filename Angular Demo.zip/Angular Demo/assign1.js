var app = angular.module("myApp",[]);
app.controller("myCtrl",function($scope){
    $scope.rate;
    $scope.principle;
    $scope.duration;
    $scope.compute=function(){
        var result = this.rate*this.principle*this.duration;
        if(isNaN(result)){
           // return "Please enter a value";
            return "";
        }else{
            return result;
            console.log(result);
        }
    }
})