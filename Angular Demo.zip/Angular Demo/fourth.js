var myApp=angular.module("myApp",['uifilter']);
myApp.controller("myCtrl", function($scope){
    
    var products=[
        {productName:"Rin",productCost:400.312,description:"This is detergent powder",  category:"Detergent",   icon:"images/Rin.jpg",expiryDate:"1"},
        
        {productName:"Doll",productCost:500.133,description:"This is Toy",              category:"Toys",        icon:"images/Doll.jpg",expiryDate:"5"},
        
        {productName:"Ariel",productCost:300.1333,description:"This is detergent powder",category:"Detergent",  icon:"images/Ariel.jpg",expiryDate:"8"},
        
        {productName:"Chair",productCost:456.98,description:"This is Toy",               category:"Toys",       icon:"images/Chiar.jpg",expiryDate:"9"},
        
        {productName:"Mobile",productCost:12345,description:"This is Gadget",           category:"Gadget",      icon:"images/Mobileimage.jpg",expiryDate:"11"},
        
        {productName:"Laptop",productCost:234567,description:"This is Gadget",          category:"Gadget",      icon:"images/Laptop.jpg",expiryDate:"1"},
        
        {productName:"Colgate",productCost:75.67,description:"This is general",         category:"general",     icon:"images/Colgate.jpg",expiryDate:"15"},
        
        {productName:"Board",productCost:123,description:"This is general",             category:"general",     icon:"images/Board.jpg",expiryDate:"7"}
    ];
    $scope.currentRecord=0;
    $scope.recordLimit=3;
    $scope.products=products;
    $scope.getExpiryDate=function(expiry){
        var now=new Date();
        return now.setDate(now.getDate()+parseInt(expiry));
    }
    $scope.next=function(){
        $scope.currentRecord=$scope.currentRecord+$scope.recordLimit;
    }
    $scope.prev=function(){
         $scope.currentRecord=$scope.currentRecord-$scope.recordLimit;
    }
                 })

myApp.filter("myFilter",function(){
    return function(input , $index){
       return input.splice($index,3);
    };
})