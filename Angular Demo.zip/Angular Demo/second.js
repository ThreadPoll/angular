var myApp=angular.module("myApp",[]);
myApp.controller("productController", function($scope){
    $scope.listProducts = function(){
        alert("on mouse");
         $scope.products=products;
    }
    
    $scope.emptyProducts = function(){
         $scope.products=[];
    }
    var products=[
        {productid:1,name:"rin",productprice:456.00,prodimage:"images/Rin.jpg"},
        {productid:2,name:"Ariel",productprice:123.45,prodimage:"images/Ariel.jpg"},
        {productid:1,name:"Colgate",productprice:76.00,prodimage:"images/Colgate.jpg"}
    ];
                 })