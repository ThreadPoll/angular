angular.module("myApp",[]).controller("productController", function($scope){
    var name="Divakar";
        
        $scope.name=name;
                 })