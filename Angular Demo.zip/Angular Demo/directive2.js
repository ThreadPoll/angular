var myDir = angular.module("mydir",[])
myDir.directive("addItem",function(){
    var obj={
        template:'limit contains <input type="text" ng-model="limit"/><br/><input type="button" value="update" ng-click="notify()"/>',
        restrict:'AEC',
        scope:{
            limit:'=',
            notify:'&'
        }
    }
    return obj;
})