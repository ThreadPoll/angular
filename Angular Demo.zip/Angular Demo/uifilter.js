var myApp = angular.module("uifilter",[]);
myApp.filter("pagination",function(input,params){
    var index=0;
    var record = [];
    var currentIndex = params[0];
    var limit = params[1];
    
    for(var count=currentIndex; count<currentIndex+limit; count++){
        record[index]= input[count];
        index++;
    }
    return record;
})