package com.demo.example.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.example.domain.Employee;
import com.demo.example.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("/")
	public List<Employee> getAllEmployee(){
		return employeeService.listAll();
	}
	
	@RequestMapping("/add/{id}/{name}/{salary}")
	public Employee addEmployee(@PathVariable long id , @PathVariable String name,@PathVariable double salary){
		Employee employee = new Employee(id, name, salary);
		return employeeService.saveEmployee(employee);
	}
	
	@RequestMapping("/delete/{id}")
	public void deleteEmployee(@PathVariable long id){
		employeeService.deleteEmployee(id);
	}
	
	@RequestMapping("/find/{id}")
	public Employee findEmployee(@PathVariable long id){
		return employeeService.getEmployeeById(id);
	}
}
