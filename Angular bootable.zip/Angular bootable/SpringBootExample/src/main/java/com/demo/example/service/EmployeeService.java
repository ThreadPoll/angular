package com.demo.example.service;

import java.util.List;

import com.demo.example.domain.Employee;

public interface EmployeeService {
	public List<Employee> listAll();
	public Employee getEmployeeById(long id);
	public Employee saveEmployee(Employee employee);
	public void deleteEmployee(long id);
}
