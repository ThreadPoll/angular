package com.demo.example.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.example.domain.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{

	public Employee findById(long id);
}
